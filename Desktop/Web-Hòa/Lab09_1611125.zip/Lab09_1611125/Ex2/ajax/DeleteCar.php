<?php

require_once "../DbConfig.php";
require_once "../publicfunc.php";

$db = new Db();
$idCar = $_POST['carId'];
$query = "DELETE FROM cars WHERE id = '$idCar'";
$result = $db->ExecuteQuery($query);
// echo json_encode([
//   "status" => "success"

// ]);
$msg = "Add new Success";
setRespone(200, $msg, "");

?>
