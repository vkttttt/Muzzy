
function createCookie(cname, cvalue, cexpire) {
  let d = new Date();
  d.setTime(d.getTime() + (cexpire * 1000 * 24 * 60 * 60));
  let expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" +  cvalue + "; " +  expires;
}


function getCookie(cname) {
  let name = cname + "=";
  let listCookie = document.cookie.split(";");
  for (let i = 0; i < listCookie.length; i++) {
    const element = listCookie[i].trim();
    if (element.indexOf(name) == 0) {
      return element.substr(name.length, element.length);
    }
  }
  return "";
}


function deleteCookie(cname) {
  let d = new Date();
  d.setTime(d.getTime() - (1000 * 60 * 60 * 24));
  let expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" + "; " + expires;
}


function checkCookie() {
  let visitor = getCookie("User");
  if (visitor != "") {
    let welcom_msg = document.getElementById("welcome-msg");
    welcom_msg.innerHTML = "Hello " + visitor;
  }
  else {
    visitor = prompt("Input your name");
    if (visitor != "" && visitor != null) {
      createCookie("User", visitor, 30);
    }
  }
}


function loadListCookie() {
  let list_cookie = document.getElementById("list-cookie");
  let arrCookie = document.cookie.split(";");
  for (let i = 0; i < arrCookie.length; i++) {
    let tempelement = arrCookie[i].trim();
    let element = tempelement.split("=");

    let trElement = document.createElement("tr");
    
    let thElement = document.createElement("th");
    thElement.setAttribute("scope", "row");
    thElement.innerHTML = i + 1;
    trElement.appendChild(thElement);

    let tdNameElement = document.createElement("td");
    tdNameElement.innerHTML = element[0];
    trElement.appendChild(tdNameElement);

    let tdValueElement = document.createElement("td");
    tdValueElement.innerHTML = element[1];
    trElement.appendChild(tdValueElement);

    list_cookie.appendChild(trElement);
  }
}


function createACookie() {
  let cname = document.getElementById("cname").value;
  let cvalue = document.getElementById("cvalue").value;
  let exdays = document.getElementById("exdays").value;
  createCookie(cname, cvalue, exdays);
  window.location.reload();
}


function deleteACookie(){
  let cname = window.document.getElementById('cname').value;
  deleteCookie(cname);
  window.location.reload();
}