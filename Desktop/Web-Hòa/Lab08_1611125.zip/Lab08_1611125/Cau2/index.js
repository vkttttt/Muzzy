/**
 * Create a cookie
 * @param {String} cname : Cookie name
 * @param {String} cvalue : Cookie value
 * @param {Int} cexpire : Numbers of day before cookie expires
 */
function createCookie(cname, cvalue, cexpire) {
  let d = new Date();
  d.setTime(d.getTime() + (cexpire * 1000 * 24 * 60 * 60));
  let expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" +  cvalue + "; " +  expires;
}

/**
 * Get a cookie, return value of coolie via name, if not exist cookie return ""
 * @param {String} cname : Coookie name
 */
function getCookie(cname) {
  let name = cname + "=";
  let listCookie = document.cookie.split(";");
  for (let i = 0; i < listCookie.length; i++) {
    const element = listCookie[i].trim();
    if (element.indexOf(name) == 0) {
      return element.substr(name.length, element.length);
    }
  }
  return "";
}

/**
 * Delete cookie via name
 * @param {String} cname : Cookie name
 */
function deleteCookie(cname) {
  let d = new Date();
  d.setTime(d.getTime() - (1000 * 60 * 60 * 24));
  let expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" + "; " + expires;
}

/**
 * Check visited website
 */
function checkCookie() {
  let visitor = getCookie("visitorname");
  if (visitor != "") {
    let welcom_msg = document.getElementById("welcome-msg");
    welcom_msg.innerHTML = "Welcome " + visitor;
  }
  else {
    visitor = prompt("Nhập vào tên của bạn");
    if (visitor != "" && visitor != null) {
      createCookie("visitorname", visitor, 30);
    }
  }
}

/**
 * Load list cookie curent
 */
function loadListCookie() {
  let list_cookie = document.getElementById("list-cookie");
  let arrCookie = document.cookie.split(";");
  for (let i = 0; i < arrCookie.length; i++) {
    let tempelement = arrCookie[i].trim();
    let element = tempelement.split("=");

    let trElement = document.createElement("tr");
    
    let thElement = document.createElement("th");
    thElement.setAttribute("scope", "row");
    thElement.innerHTML = i + 1;
    trElement.appendChild(thElement);

    let tdNameElement = document.createElement("td");
    tdNameElement.innerHTML = element[0];
    trElement.appendChild(tdNameElement);

    let tdValueElement = document.createElement("td");
    tdValueElement.innerHTML = element[1];
    trElement.appendChild(tdValueElement);

    list_cookie.appendChild(trElement);
  }
}

/**
 * Create new cookie and reload page
 */
function createACookie() {
  let cname = document.getElementById("cname").value;
  let cvalue = document.getElementById("cvalue").value;
  let exdays = document.getElementById("exdays").value;
  createCookie(cname, cvalue, exdays);
  window.location.reload();
}

/**
 * Delete cookie via cookie name
 */
function deleteACookie(){
  let cname = window.document.getElementById('cname').value;
  deleteCookie(cname);
  window.location.reload();
}